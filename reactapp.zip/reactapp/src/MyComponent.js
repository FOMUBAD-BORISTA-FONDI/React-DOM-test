import React from 'react';

const MyComponent = (props) => {
  return <div className="select">{props.children}</div>;
}

export default MyComponent;
